  # CTI-110

   # P3HW2 - Salary

   # Sean Davis
   # 28 March 2023

   


name = input("Enter employee's name:  ")
hours = float(input("Enter number of hours worked:  "))
payrate = float(input("Enter employee's pay rate:  "))

ovthrs = 0.0
ovtpay = 0.0
if hours > 40:
       regpay = payrate * 40
       ovthrs = hours - 40
       ovtpay = payrate * ovthrs * 1.5
       grosspay = ovtpay + regpay
else:
   regpay = hours * payrate
   grosspay = ovtpay + regpay
print('------------------------------------------------------------------------------')
print('Employee name:', name)

print()
print("Hours Worked"+" "*5 +"Pay Rate"+" "*5 +"Overtime"+" "*5 +"Overtime Pay"+" "*5 +"RegHour Pay"+" "*5 +"Gross Pay")
print('-----------------------------------------------------------------------------------------------------------')

print(hours,'\t\t',payrate,'\t\t',ovthrs,'\t'+'   $' + str(format(ovtpay,',.2f'))+'\t'+ '   $' + str(format(regpay,',.2f')) + '\t' + '   $' + str(format(grosspay,',.2f')))

