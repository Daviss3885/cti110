# I was supposed to put a comment here
# My Last Name


# This program takes a number grade , determines average and displays letter grade for average.

# Enter grades for six modules

mod_1 = float(input('Enter grade for Module 1: '))
mod_2 = float(input('Enter grade for Module 2: '))
mod_3 = float(input('Enter grade for Module 3: '))
mod_4 = float(input('Enter grade for Module 4: '))
mod_5 = float(input('Enter grade for Module 5: '))
mod_6 = float(input('Enter grade for Module 6: '))


grades = [mod_1, mod_2, mod_3, mod_4, mod_5, mod_6]

low = min(grades)
max = max(grades)
sum = sum(grades)
avg = sum/len(grades)


print("-"*12,'Results',12*'-')
print('Lowest Grade:'+ str(format(low,'.2f')).rjust(15)) 
print('Highest Grade:'+ str(format(max,'.2f')).rjust(14)) 
print('Sum of Grades:'+ str (format(sum,'.2f')).rjust(15)) 
print('Average:'+ str(format(avg,'.2f')).rjust(20)) 
print('-'*41)



if avg >= 90:
    print('Your grade is: A')
else:
    if avg > 80:
        print('Your grade is: B')
    else:
        if avg > 70:
            print('Your grade is: C')    
        else:
            if avg > 60:
                print('Your grade is: D')
            else:
                print('Your grade is: F') 





