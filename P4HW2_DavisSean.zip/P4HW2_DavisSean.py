Python 3.11.2 (tags/v3.11.2:878ead1, Feb  7 2023, 16:38:35) [MSC v.1934 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: C:/Users/seand/AppData/Local/Programs/Python/Python311/P4HW2_DavisSean.py
Enter employee's name or Done to terminate: Nancy Drew
How many hours did Nancy Drew work? 39
What is Nancy Drew's pay rate: 20
Employee Name: Nancy Drew
39.0

Enter employee's name or Done to terminate: Rick Hardy
How many hours did Rick Hardy work? 45
What is Rick Hardy's pay rate: 18.5
Employee Name: Rick Hardy
45.0

Enter employee's name or Done to terminate: Done
Total number of employees entered:  2
Total ampunt paid for overtime:  138.75
Total amount paid for regular hours:  1520.0
Total amount paod in gross:  1658.75

Program has terminated
